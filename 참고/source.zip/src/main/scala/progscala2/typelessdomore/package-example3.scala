// src/main/scala/progscala2/typelessdomore/package-example3.scala
// 'example'에 있는 모든 패키지 수분의 선언을 영역으로 가져온다.
package com.example
// `mypkg`에 있는 모든 패키지 수준의 선언을 영역으로 가져온다.
package mypkg

class MyPkgClass {
  // ...
}
