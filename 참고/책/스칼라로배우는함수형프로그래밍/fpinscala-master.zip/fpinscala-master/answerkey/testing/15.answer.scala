/* A detailed answer is to be found in the file Exhaustive.scala in the code
   accompanying this chapter. */