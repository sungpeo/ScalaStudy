Again, see `parsing/instances/Reference.scala` for a fully worked implementation.
