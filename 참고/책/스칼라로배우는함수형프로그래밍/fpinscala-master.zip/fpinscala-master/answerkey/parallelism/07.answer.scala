/* 
See https://github.com/quchen/articles/blob/master/second_functor_law.md

Also https://gist.github.com/pchiusano/444de1f222f1ceb09596
*/
