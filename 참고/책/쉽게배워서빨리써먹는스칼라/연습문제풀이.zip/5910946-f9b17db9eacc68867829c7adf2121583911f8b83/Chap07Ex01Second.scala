package com
package horstmann
package impatient

object Chap07Ex01Second extends App {
  println("package com/horstmann/impatient 따로 지정은 import 불필요 : " + Chap07Ex01Consts.horstmannValue)
}