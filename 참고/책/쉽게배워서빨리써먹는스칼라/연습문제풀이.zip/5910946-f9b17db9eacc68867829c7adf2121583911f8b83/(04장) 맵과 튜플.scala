import scala.collection.mutable

/** Chapter 04 **/
/*
1.사고 싶은 여러 장치의 가격 맵을 만들라. 그러고 나서 Key는 같고 가격은 10% 할인된
두 번째 맵을 생성하라.
 */
println("# 4.1 --")
val devices = scala.collection.immutable.Map("넥서스4" -> 459000, "넥서스7" -> 330000)
val discountedDevices = for ((k, v) <- devices) yield (k, (v * 0.9).toInt)
println("10% 할인 : " + discountedDevices)

/*
2. 파일에서 단어들을 읽어 들이는 프로그램을 작성하라. 각 단어가 얼마나 빈번하게 등장하는지
세는 수정 가능한 맵을 이용하라. 단어를 읽어 들이는 데는 간단히 java.util.Scanner를
사용하라.

val in = new java.util.Scanner(new java.io.File("myfile.txt"))
while (in.hasNext()) process in.next()

또는 9장의 스칼라 방식을 참조하라.

마지막에 모든 단어와 횟수를 추력하라.
*/
println("# 4.2 --")

val in = new java.util.Scanner(new java.io.File("./scripts/(04장) 맵과 튜플.scala"))
val words = new mutable.HashMap[String, Int]
while (in.hasNext()) {
  val word = in.next()
  words(word) = words.getOrElse(word, 0) + 1
}

for ((word, count) <- words) {
  printf("단어 \"%s\" -> %d%n", word, count)
}

/*
3. 2번 문제를 수정 불가능한 맵으로 반복한라.
 */
println("# 4.3 --")

val ex3In = new java.util.Scanner(new java.io.File("./scripts/(04장) 맵과 튜플.scala"))
var ex3Words = new scala.collection.immutable.HashMap[String, Int]
while (ex3In.hasNext) {
  val word = ex3In.next()
  ex3Words = ex3Words + (word -> (ex3Words.getOrElse(word, 0) + 1))
}

for ((word, count) <- ex3Words) {
  printf("단어 \"%s\" -> %d%n", word, count)
}

/*
4. 2번 문제를 단어가 정렬되어 출력되게 정렬 맵으로 반복하라.
 */
println("# 4.4 --")

val ex4In = new java.util.Scanner(new java.io.File("./scripts/(04장) 맵과 튜플.scala"))
val ex4Words = new mutable.HashMap[String, Int]
while (ex4In.hasNext()) {
  val word = ex4In.next()
  ex4Words(word) = ex4Words.getOrElse(word, 0) + 1
}

val sortedWords = scala.collection.immutable.SortedMap[String, Int](ex4Words.toArray: _*)
for ((word, count) <- sortedWords) {
  printf("단어 \"%s\" -> %d%n", word, count)
}

/*
5. 2번 문제를 java.util.TreeMap을 스칼라 API로 개조해서 반복하라.
 */
println("# 4.5 --")

import java.util.TreeMap
import scala.collection.JavaConversions.mapAsScalaMap

val ex5In = new java.util.Scanner(new java.io.File("./scripts/(04장) 맵과 튜플.scala"))
val ex5Words = new TreeMap[String, Int]
while (ex5In.hasNext()) {
  val word = ex5In.next()
  val count = if (ex5Words.containsKey(word)) ex5Words.get(word) else 0
  ex5Words.put(word, count + 1)
}

for ((word, count) <- ex5Words) {
  printf("단어 \"%s\" -> %d%n", word, count)
}
/*
6. "Mondy"를 java.util.Calendar.MONDAY로 매핑하고 다른 요일도 비슷한 방식으로 매핑하는
링크 해시 맵을 정의하라. 원소는 삽입된 순서로 방문이 일어남을 보이라.
 */
println("# 4.6 --")

import java.util.Calendar._
val days = scala.collection.mutable.LinkedHashMap ("Monday" -> MONDAY, "Tuesday" -> TUESDAY,
  "Wednesday" -> WEDNESDAY, "Thursday" -> THURSDAY, "Friday" -> FRIDAY, "Saturday" -> SATURDAY,
  "Sunday" -> SUNDAY)

for ((word, value) <- days) {
  printf("요일 %s -> %d\n", word, value)
}

/*
7. 다음과 같이 모든 자바 속성의 표를 출력하라.

키 이름          | 값
...

테이블을 출력하기 전에 가장 긴 키의 길이를 찾아야 할 것이다.
 */
println("# 4.7 --")

import scala.collection.JavaConversions.propertiesAsScalaMap
val props : scala.collection.Map[String, String] = System.getProperties()
var longestLength = 0;
for (key <- props.keySet) {
  longestLength = if (key.length > longestLength) key.length else longestLength
}

for ((key, value) <- props) {
  printf("%-" + (longestLength + 1) +"s | %s%n", key, value)
}

/*
8. 배열에서 가장 작은 수와 큰 수의 쌍을 리턴하는 minmax(values: Array[Int])
함수를 작성하라.
 */
println("# 4.8 --")

def minmax(values: Array[Int]) : (Int, Int) = {
  (values.min, values.max)
}
val (min, max) = minmax(Array(4, 32,65,34,78,32,12,65,76,98,0,5,2,34))
printf("Min : %d, Max : %d%n", min, max)

/*
9. v보다 작은 수의 개수, v와 같은 수의 개수, v보다 큰 수의 개수를 트리플로 리턴하는
lteqgt(values: Array[Int], v: Int) 함수를 작성하라.
 */
println("# 4.9 --")
def lteqgt(values: Array[Int], v: Int) : (Int, Int, Int) = {
  var lt = 0
  var eq = 0
  var gt = 0

  for (value <- values) {
    if (value > v) { gt += 1}
    else if (value < v) { lt += 1}
    else eq += 1
  }
  (lt, eq, gt)
}

val (lt, eq, gt) = lteqgt(Array(1,2,3,4,5,6,7,8,9,5,6,3,4,7,8,9,5,2,4,5,7), 5)
printf("lt : %d, eq : %d, gt %d%n", lt, eq, gt)
/*
10. "Hello".zip("World")와 같이 두 문자열을 집(zip)하면 무슨일이 생기나? 가능한
유스 케이스를 생각하라?
 */
println("# 4.10 --")
println("zip : " + "Hello".zip("World"))