/** Chapter 05 **/

/*
1. "5.1 간단한 클래스와 인자 없는 메소드"에 나온 Counter 클래스를 Int.MaxValue에서 음수가 되지 않게 개선하라.
*/
println("# 5.1 ---")
class Counter(private var value : Int) {
  def increment() {
    if (value < Int.MaxValue) {
      value += 1
    }
  }
  def current = value
}

val c = new Counter(Int.MaxValue)
c.increment()
println("current : " + c.current)

/*
2. 메소드 deposit과 withdraw, 읽기 전용 프로퍼티 balance로 BankAccount 클래스를 작성하라.
*/
println("# 5.2 ---")

class BankAccount {
  private var balance = 0

  def currentBalance = balance

  def deposit(money : Int) {
    balance += money
  }

  def withdraw(money: Int) {
    balance -= money
  }
}

val ba = new BankAccount
ba.deposit(50000)
ba.withdraw(3000)
println("current balance : " + ba.currentBalance)

/*
3. 읽기 전용 프로퍼티 hours와 minutes, 이 시간이 다른 시간보다 앞선 시간인지 확인하는
before(other: Time): Boolean 메소드를 가진 Time 클래스를 작성하라. Time 오브젝트는
new Time(hrs, min)으로 생성할 수 있어야 하는데, 여기서 hrs는 군용 시간 형식(0과 23사이)이다.
*/
println("# 5.3 ---")

class Time(private var hrs : Int, private var min : Int) {
  def description = hrs + "H " + min + "m"
  def before(other: Time): Boolean = {
    (hrs * 60 + min) < (other.hrs * 60 + other.min)
  }
}

val t1 = new Time(19,37)
println("before false 여야함 : " + t1.before(new Time(19, 36)))
println("before true 여야함 : " + t1.before(new Time(20, 30)))

/*
4. 내부 표현이 자정 이후 분(0과 24 * 60 - 1)이 되도록 이전 문제의 Time 클래스를 재구현하라.
공개 인터페이스는 변경하지 말아야 한다. 바꿔 말해 클라이언트 코드는 이 변경 사항에 영향을
받지 않아야 한다.
--> 내부적으로 데이터 저장을 hrs:min 로 하지 말고 0시 0분 이후 지난 분수로 표현하라는 뜻.
즉, 새벽 1시 10분은 70 으로 내부적으로 데이터를 보관할 것.
*/
println("# 5.4 ---")
class TimeByMinutes(private val hrs: Int, private val min : Int) {
  private val time = (hrs * 60 + min)

  def description = (time / 60)  + "H" + (time % 60) + "m"

  def before(other: TimeByMinutes): Boolean = {
    time < other.time
  }
}

val tm1 = new TimeByMinutes(19,37)
println("before false 여야함 : " + tm1.before(new TimeByMinutes(19, 36)))
println("before true 여야함 : " + tm1.before(new TimeByMinutes(20, 15)))

/*
5. 읽기-쓰기 Java Bean 프라퍼티 name(String 타입)과 id(Long 타입)을 갖는 Student 클래스를
만들라. 어떤 메소드가 생성되는가? (javap를 사용하여 확인한다.) 스칼라에서 Java Bean 게터와 세터를
호출할 수 있나? 그렇게 하는 것이 좋나?
*/
println("# 5.5 ---")
import scala.beans.BeanProperty

class Student {
  @BeanProperty var name : String = ""
  @BeanProperty var id : Long = 0
}
// scalac Student.scala
// javap -private Student
/*
Compiled from "Student.scala"
public class Student {
  private java.lang.String name;
  private long id;
  public java.lang.String name();
  public void name_$eq(java.lang.String);
  public void setName(java.lang.String);
  public long id();
  public void id_$eq(long);
  public void setId(long);
  public java.lang.String getName();
  public long getId();
  public Student();
}
 */

val s = new Student
s.setName("Fred")
s.setId(5)
println("Name : " + s.getName + ", Id : " + s.getId)
// setter/getter 호출가능하다. 웬만하면 피치 못할 경우에만 사용하지 말고, View Template 같은 곳에서만
// 사용하도록 하자.

/*
6. "5.1 간단한 클래스와 인자 없는 메소드"에 나온 Person 클래스에서 음수 나이를 0으로 바꾸는
기본 생성자를 제공하라.
-> 실제로는 Person 클래스는 5.2에 나온다.
*/
println("# 5.6 ---")

class Person(private var privateAge: Int) {
  if (privateAge < 0) {
    privateAge = 0
  }

  def age = privateAge
  def age_=(newAge: Int) {
    if (newAge > privateAge) privateAge = newAge
  }
}

val p1 = new Person(-10)
println("age changed : " + p1.age)
val p2 = new Person(10)
println("age : " + p2.age)

/*
7. new Person("Fred Smith")와 같이 이름, 공백, 성을 포함한 문자열을 받는 기본 생성자가 있는
Person 클래스를 작성하라. 읽기 전용 프로퍼티인 firstName과 lastName을 제공하라. 기본 생성자
인자는 var, val, 일반 인자 중 어느 것이어야 하나? 왜 그런가?
*/
println("# 5.7 ---")

class PersonSeven(name: String) {
  private val names = name.split(" ")

  def firstName = names(0)
  def lastName = names(1)
}

val ps = new PersonSeven("Fred Smith")
println("firstName : " + ps.firstName + ", lastName : " + ps.lastName)

// 기본생성자는 일반 인자를 사용한다. 외부로 전혀 노출될 이유가 없기 때문이다.

/*
8. 제조사, 모델명, 모델 연도를 읽기 전용 프로퍼티로 가지고 번호판을 읽기-쓰기 프로퍼티로 가지는
Car 클래스를 만들어라. 네개의 생성자를 제공하라. 모든 생성자는 제조사와 모델명을 요구한다.
선택적으로, 모델 연도와 번호판을 생성자에 지정할 수 있다. 그렇지 않으면 모델 연도는 -1이 되고
번호판은 빈 문자열이 된다. 어느 생성자를 기본 생성자로 선택할 것인가? 왜 그런가?
*/

println("# 5.8 ---")
class Car(val manufacturer: String, val modelName: String) {
  private var modelYear: Int = -1
  var licensePlate: String = ""

  def this(manufacturer: String, modelName: String, modelYear: Int) {
    this(manufacturer, modelName)
    this.modelYear = modelYear
  }

  def this(manufacturer: String, modelName: String, licensePlate: String) {
    this(manufacturer, modelName)
    this.licensePlate = licensePlate
  }

  def this(manufacturer: String, modelName: String, modelYear: Int, licensePlate: String) {
    this(manufacturer, modelName, modelYear)
    this.licensePlate = licensePlate
  }

  override def toString = "Car { manufacturer: " + manufacturer + ", modelName: " + modelName + ", year: " + modelYear + ", licensePlate: " + licensePlate + "}"
}

val car = new Car("Hyundai", "Santafe R", 2012, "가나1234")
println(car)
car.licensePlate = "아자차4567"
println(car)
// car.modelYear = 2011 // Error!
// car.manufacturer = "Kia" // Error!
// car.modelName = "Sonata" // Error!

// 항상 필요한 manufacturer와 modelName을 기본생성자로 구현한다.

/*
9. 8번 문제의 클래스를 자바, C# 혹은 C++(원하는 선택으로) 재구현하라.
*/
println("# 5.8 --- pass")

/*
10. 다음 클래스를 살펴보고 이 클래스를 명시적인 필드와 디폴트 기본 생성자를 이용하여 재작성하라.
어떤 형태를 더 선호하는가? 왜 그런가?

class Employee(val name: String, var salary: Double) {
  def this() { this("John Q. Public", 0.0) }
}
*/

// from http://stackoverflow.com/questions/10426146/constructors-in-scala-primary-auxiliary-default-primary/10999828#10999828
// var, val 에 주의해서 필드를 생성해야한다.

class Employee {
  private var _name = "John Q. Public"
  var salary: Double = 0.0
  def this(name: String, salary: Double) {
    this()
    _name = name
    this.salary = salary
  }
  def name = _name
}

val e = new Employee
println("Employee " + e.name + ", " + e.salary)

// 기본 생성자가 나은 듯 하다. 필드들을 원하는 형태로 즉각 생성할 수 있다.
// 그에반해 필드를 명시적으로 해야 할 경우에는 접근자를 복잡하게 만들어야 한다.
