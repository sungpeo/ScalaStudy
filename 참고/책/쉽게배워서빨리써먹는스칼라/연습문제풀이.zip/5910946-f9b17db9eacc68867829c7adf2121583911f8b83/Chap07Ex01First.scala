package com.horstmann.impatient

import com.horstmann.Chap07Ex01Consts

object Chap07Ex01First extends App {
  println("com.horstmann.impatient 에서는 명시적 improt 필요 : " + Chap07Ex01Consts.horstmannValue)
}
