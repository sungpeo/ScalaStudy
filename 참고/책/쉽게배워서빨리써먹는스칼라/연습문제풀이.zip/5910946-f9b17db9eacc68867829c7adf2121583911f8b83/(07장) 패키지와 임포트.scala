/** Chapter 07 **/

/*
1. package com.horstmann.impatient가

package com
package horstmann
package impatient
와 동일하지 않음을 보여주는 예제 프로그램을 작성하라.
*/
println("# 7.1 ---")

/* Chap07Ex01Constas.scala
package com.horstmann

object Chap07Ex01Consts {
  val horstmannValue = "Horstmann's scala for the impatient."
}

*/

/* Chap07Ex01Firstcala
package com.horstmann.impatient

import com.horstmann.Chap07Ex01Consts

object Chap07Ex01First extends App {
  println("com.horstmann.impatient 에서는 명시적 improt 필요 : " + Chap07Ex01Consts.horstmannValue)
}
*/


/* Chap07Ex01Secondcala
package com
package horstmann
package impatient

object Chap07Ex01Second extends App {
  println("package com/horstmann/impatient 따로 지정은 import 불필요 : " + Chap07Ex01Consts.horstmannValue)
}
*/

/*
2. 최상위에 있지 않은 com 패키지를 이용하여 스칼라 친구를 골탕먹이는 퍼즐러를 작성하라.
*/

println("# 7.2 ---")

/* Chap07Ex02FakeCom.scala
package com.horstmann

object Chap07Ex02FakeCom {
  val someValue = "wanted value!"
}

package impatient.com.horstmann {
  object Chap07Ex02FakeCom {
    val someValue = "fake value! -.-"
  }
}
*/

/* Chap07Ex02Fooled.scalaackage com.horstmann.impatient

object Chap07Ex02Fooled extends App {
  println(com.horstmann.Chap07Ex02FakeCom.someValue)
}
*/

// 이 결과로  "fake value! -.-" 가 출력된다.

/*
3. nextInt(): Int, nextDouble(): Double, setSeed(seed: Int): Unit 함수가 있는
random 패키지를 작성하라. 임의의 수 생성에는 다음 선형 합동 생성기를 사용하라.

next = previous * a + b % 2n -> 책에 오타. 책에는 2의 n제곱으로 표기 돼 있음.

여기서 a = 1664525, b = 1013904223, n = 32이다.
*/
println("# 7.3 ---")

/* Chap07Ex02-random-package.scala
package random

package object random {
  private val a = 1664525
  private val b = 1013904223
  private val n = 32

  private var seed : Int = 0

  def next(): Double = {
    seed = seed * a + b % (2 * n)
    seed
  }

  def nextDouble(): Double = {
    next()
  }

  def nextInt(): Int = {
    next().toInt
  }

  def setSeed(seed: Int) {
    this.seed = seed
  }
}

object Test extends App {
  random.setSeed(123123)
  println("NextInt : " + random.nextInt())
  println("NextInt : " + random.nextInt())
  println("NextInt : " + random.nextInt())

  println("NextDouble : " + random.nextDouble())
  println("NextDouble : " + random.nextDouble())
  println("NextDouble : " + random.nextDouble())
}

*/

/*
4. 스칼라 언어 설계자는 왜 단순히 패키지에 함수와 변수를 추가할 수
있게 허용하는 대신 패키지 오브젝트 문법을 제공핬다고 생각하나?
*/

println("# 7.4 ---")
println("""
Java 언어가 package에 멤버를 둘 수 있게 허용하지 않으므로
Package Object를 통해 클래스 package라는 클래스 객체로써 문제 해결.
""")

/*
5. private[com] def giveRaise(rate: Double)의 의미는 무엇인가? 이는 유용한가?
*/
println("# 7.5 ---")
println("""
com 패키지 멤버들이 볼 수 있는 메소드 giveRaise() 선언.
별로 필요할 것 같지는 않다.
""")

/*
6. 자바 HashMap에서 스칼라 HashMap으로 모든 원소를 복사하는 프로그램을 작성하라.
임포트를 사용하여 두 클래스의 이름을 변경하라.
*/
println("# 7.6 ---")


import java.util.{HashMap => JavaHashMap}
val javaHashMap = new JavaHashMap[String, Int]
javaHashMap.put("하나", 1)
javaHashMap.put("둘", 2)
javaHashMap.put("셋", 3)

import scala.collection.mutable.{HashMap => ScalaHashMap}
val scalaHashMap = new ScalaHashMap[String, Int]

import scala.collection.JavaConversions._
for ((k, v) <- javaHashMap) {
  scalaHashMap += (k -> v)
}
println("ScalaHashMap : " + scalaHashMap)

/*
7. 6번 문제에서 모든 임포트는 최대한 안쪽 스코프로 옮기라.
*/
println("# 7.7 ---")
println("6번 자체를 수정함.")

/*
8.
import java._
import javax._
의 효과는 무엇인가? 이는 좋은 생각인가?
*/
println("# 7.8 ---")

println(
  """
    |java 와 javax 패키지는 동일한 이름의 하위 패키지를 가지고 있다.
    |이에 따라 패키지를 줄여 쓸 경우 올바르게 작동하지 않는다.
  """.stripMargin)

/*
9. java.lang.System 클래스를 임포트하고, user.name 시스템 프라퍼티에서
사용자 이름을 읽고, Console 오브젝트에서 암호를 읽어 암호가 "secret"가
아니면 표준 에러 스트림으로 메시지를 출력하는 프로그램을 작성하라.
암호가 맞으면 표준 출력 스트림으로 인사를 출력하라. 다른
임포트는 사용하지 말고 전체 이름(점이 있는)도 사용하지 말아야 한다.
*/

println("# 7.9 ---")

println("Console이 java.io.Console이 아니라 scala.Console이라는게 함정.")

import java.lang.System
val userName = System.getProperty("user.name")
println(userName)
val password = Console.readLine("password : ")
if (password == "secret") {
  Console.out.println("Hello, " + userName)
} else {
  Console.err.println("Wrong password")
}

/*
10. StringBuilder 말고 scala 패키지가 덮어쓰는 java.lang 멤버는 무엇이 있는가?
*/
println("# 7.10 ---")
println(
  """
    |대분의의 기본형 클래스들. Integer, Long, Boolean, ...
    |
  """.stripMargin)