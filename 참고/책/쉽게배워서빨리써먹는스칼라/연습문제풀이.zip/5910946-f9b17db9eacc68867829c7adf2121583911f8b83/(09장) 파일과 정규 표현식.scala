/** Chapter 09 **/

/*
1. 파일 내의 줄을 뒤집는 (마지막 줄을 첫 번째로 만드는 등) 스칼라 코드 조각을 작성하라.
*/
println("## 9.1 ---")

import scala.io._
import java.io._

val filename: String = "scripts/(09장-1)test.txt"
val source = Source.fromFile(filename)
val reversedLines: Array[String] = source.getLines.toArray.reverse
source.close()

val out = new PrintWriter(filename)
for (line <- reversedLines) out.println(line)
out.close()

/*
2. 탭이 있는 파일을 읽어 탭 간격이 n 컬럼 경계에 있게 각 탭을 공백으로 치환하여 그 결과를
같은 파일에 쓰는 스칼라 프로그램을 작성하라.
--> 해석 : 탭은 기본 8컬럼인데, 두글자 쓰고 탭을 누르면 실제로는 6칸만 전진하는 식으로 항상
8의 배수 단위로 다음 위치가 정해지는 방식을 뜻하는 듯.

여기서는 탭 크기를 4로 간주하고 만든다. 같은 파일에 쓰게 되면 테스트시마다 새로운 파일을
만들어야 해서 기본 파일을 만들어 놓그 그것을 복사한 뒤에 코드를 수행한다.
*/
println("## 9.2 ---")

import java.nio.file.Files
import java.nio.file.Paths
import java.nio.file.StandardCopyOption.REPLACE_EXISTING

val originalFilename = "scripts/(09장-2)original.txt"
val workFilename = "scripts/(09장-2)work.txt"
Files.copy(Paths.get(originalFilename), Paths.get(workFilename), REPLACE_EXISTING)

val work92File = Source.fromFile(workFilename)
val work92Lines = work92File.getLines.toArray
work92File.close()

// ... 작성할 것

/**
3.
*/
println("## 9.3 ---")
