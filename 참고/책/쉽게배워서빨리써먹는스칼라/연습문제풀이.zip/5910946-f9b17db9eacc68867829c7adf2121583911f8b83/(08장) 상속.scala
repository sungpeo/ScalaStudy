/** Chapter 08 **/

/*
1. 다음 BankAccount 클래스를 매회 입금과 출금에 $1를 청구하는 CheckingAccount로 확장하라
*/
println("# 8.1 ---")

class BankAccount(initialBalance: Double) {
  private var balance = initialBalance
  def deposit(amount: Double) = { balance += amount; balance }
  def withdraw(amount: Double) = { balance -= amount; balance }
}

class CheckingAccount(initialBalance: Double) extends BankAccount(initialBalance) {
  override def deposit(amount: Double) = { super.deposit(amount - 1.0) }
  override def withdraw(amount: Double) = { super.withdraw(amount + 1.0) }
}

val checkingAccount = new CheckingAccount(100.0)
println("deposit 10.0 : " + checkingAccount.deposit(10.0))
println("withdraw 15.0 : " + checkingAccount.withdraw(15.0));

/*
2. 1번 문제의 BankAccount를 확장하여 (earnMonthlyInterest 메소드가 불릴 때) 매달 이자를 지급하고,
매달 3번의 공짜 입금 혹은 출금을 제공하는 SavingAccount 클래스를 만들라. 거래 횟수는
earnMonthlyInterest에서 초기화하라.
*/
println("# 8.2 ---")

class SavingAccount(initialBalance: Double, monthlyInterest: Double) extends BankAccount(initialBalance) {
  private var transactionCount = 0

  private def transactionFee : Double = { transactionCount += 1; if (transactionCount > 3) 1.0 else 0 }

  override def deposit(amount: Double) = { super.deposit(amount - transactionFee) }
  override def withdraw(amount: Double) = { super.withdraw(amount + transactionFee)}

  def earnMonthlyInterest() = {
    transactionCount = 0
    deposit(monthlyInterest)
  }
}

val savingAccount = new SavingAccount(100.0, 2.0)
println("deposit 1.0 1 : " + savingAccount.deposit(1.0));
println("deposit 1.0 2 : " + savingAccount.deposit(1.0));
println("deposit 1.0 3 : " + savingAccount.deposit(1.0));
println("deposit 1.0 4 : " + savingAccount.deposit(1.0));
println("earnMonthlyInterest : " + savingAccount.earnMonthlyInterest());
println("withdraw 1.0 1 : " + savingAccount.withdraw(1.0));
println("withdraw 1.0 2 : " + savingAccount.withdraw(1.0));
println("withdraw 1.0 3 : " + savingAccount.withdraw(1.0));
println("withdraw 1.0 4 : " + savingAccount.withdraw(1.0));

/*
3. 종업원이나, 애완동물, 그래픽 모양 등 간단한 상속 계층 예제가 있는 Java 혹은
C++ 교과서를 참고하여 그 예제를 스칼라로 구현하라.

Java Vehicle Example: http://lanbuddy.com/java/lesson11.htm

//This is the class that will be inherited
public class Vehicle
{
    public int doors;
    public int seats;
    public int wheels;
    Vehicle()
    {
	wheels=4;
        doors=4;
	seats=4;
    }
}

//This class inherits Vehicle.java
public class Car extends Vehicle
{
    public String toString()
    {
	return "This car has "+seats+" Seats, "+doors+" Doors "+
	    "and "+wheels+" wheels.";
    }
}

//This class inherits Vehicle.java
public class MotorCycle extends Vehicle
{
    MotorCycle()
    {
	wheels=2;
        doors=0;
	seats=1;
    }
    void setSeats(int num)
    {
	seats=num;
    }
    public String toString()
    {
	return "This motorcycle has "+seats+" Seats, "+doors+" Doors "+
	    "and "+wheels+" wheels.";
    }
}

//This class inherits Vehicle.java
public class Truck extends Vehicle
{
    boolean isPickup;
    Truck()
    {
	isPickup=true;
    }
    Truck(boolean aPickup)
    {
	this();
	isPickup=aPickup;
    }
    Truck(int doors, int seats, int inWheels, boolean isPickup)
    {
	this.doors=doors;
	this.seats=seats;
	wheels=inWheels;
	this.isPickup=isPickup;
    }
    public String toString()
    {
	return "This "+(isPickup?"pickup":"truck")+
	  " has "+seats+" Seats, "+doors+" Doors "+"and "+wheels+" wheels.";
    }
}
*/

println("# 8.3 ---")

//This is the class that will be inherited
class Vehicle(val doors: Int = 4, val seats: Int = 4, val wheels: Int = 4) {
}

class Car(doors: Int = 4, seats: Int = 4, wheels: Int = 4) extends Vehicle(doors, seats, wheels) {
  override def toString: String = { "This car has " + seats + " Seats, " + doors + " Doors and " + wheels + " wheels."}
}

class MotorCycle(seats: Int = 1) extends Vehicle(4, seats, 2) {
  override def toString: String = { "This motorcycle has " + seats + " Seats, " + doors + " Doors and " + wheels + " wheels."}
}

class Truck(isPickup: Boolean = true, doors: Int = 4, seats : Int = 4, wheels: Int = 4) extends Vehicle(doors, seats, wheels) {

  override def toString: String = { "This " + (if (isPickup) "pickup" else "truck") + " has " + seats + " Seats, " + doors + " Doors and " + wheels + " wheels."}
}

println("Car : " + new Car(2));
println("MotorCycle : " + new MotorCycle(2))
println("Truck : " + new Truck(true, 2, 4, 12))

/*
4. price와 description 메소드가 있는 추상 클래스 Item을 정의하라. SimpleItem은 가격과 설명을
생성자에 지정하는 아이템이다. val이 def를 오버라이드할 수 있다는 사실을 이용하기 바란다.
Bundle은 다른 아이템을 들고 있는 아이템이다. Bundle의 가격은 번들 내 가격들의 합이다.
또한 번들에 아이템을 추가하는 방법과 적절한 description 메소드도 제공하라.
*/
println("# 8.4 ---")

abstract class Item {
  def price: Double
  def description: String
}

class SimpleItem(override val price: Double, override val description: String) extends Item {
}

val simpleItem = new SimpleItem(10.0, "간단한 아이템")
println("simpleItem : " + simpleItem.price + ", " + simpleItem.description)

import scala.collection.mutable
import scala.collection.mutable._

class Bundle extends Item {
  val items: ArrayBuffer[Item] = ArrayBuffer()

  def add(item: Item) {
    items += item
  }

  def price: Double = {
    var sum = 0.0
    for (item <- items) {
      sum += item.price;
    }
    sum
  }
  def description: String = {
    val descriptions = mutable.StringBuilder.newBuilder
    descriptions.append("* Items")
      .append(" : $")
      .append(price)
      .append("\n")
    for (item <- items) {
      descriptions.append(" - ")
        .append(item.description)
        .append(" $")
        .append(item.price)
        .append("\n")
    }
    descriptions.toString()
  }
}

val bundle = new Bundle
bundle.add(new SimpleItem(5.0, "햄버거"))
bundle.add(new SimpleItem(1.0, "콜라"))
bundle.add(new SimpleItem(1.5, "감자칩"))

println("bundle : $" + bundle.price + "\n" + bundle.description)

/*
5. x와 y 좌표를 생성자에 지정할 수 있는 Point 클래스를 설계하라. 생성자에서 레이블 값,
x와 y 좌표를 다음과 같이 받는 LabelPoint 서브클래스를 제공하라.
new LabelPoint("Black Thursday", 1929, 230.07
*/
println("# 8.5 ---")

class Point(val x: Double, val y: Double) {
  override def toString: String = { "Point("+ x + ", " + y +")" }
}
val point = new Point(4.5, 10.2)
println("포인트 " + point)

class LabelPoint(val label: String, x: Double, y: Double) extends Point(x, y) {
  override def toString: String = { "Label - " + label + "(" + x + ", " + y + ")" }
}
val label = new LabelPoint("Black Thursday", 1929, 230.07)
println("레이블 " + label)

/*
6. 추상 메소드 centerPoint가 있는 추상 클래스 Shape, 서브클래스 Rectangle과 Circle을 정의하라.
서브클래스를 위한 적절한 생성자를 제공하고 각 서브클래스의 centerPoint 메소드를 오버라이드하라.
*/
println("# 8.6 ---")

abstract class Shape(startingPoint: Point) {
  def centerPoint: Point
  override def toString: String = {"Starting Point : " + startingPoint + ", CenterPoint : " + centerPoint}
}

class Rectangle(startingPoint: Point, width: Double, height: Double) extends Shape(startingPoint) {
  override def centerPoint: Point = { new Point(startingPoint.x + (width / 2), startingPoint.y + (height / 2))}
}

class Circle(startingPoint: Point, radius: Double) extends Shape(startingPoint) {
  override def centerPoint: Point = { startingPoint }
}

println("Rectangle : " + new Rectangle(new Point(10, 10), 50, 50))
println("Circle : " + new Circle(new Point(160.0, 190.23), 230.50))

/*
7. java.awt.Rectangle을 확장하고, 다음 3개의 생성자가 있는 Square 클래스를 제공하라. 모서리점과
너비를 받는 생성자, (0.0) 모서리에 주어진 너비를 받는 생성자, (0, 0)에 너비가 0인 생성자.
*/
println("# 8.7 ---")
class Square(x: Int, y: Int, width: Int) extends java.awt.Rectangle(x, y, width, width) {
  def this(width: Int = 0) {
    this(0, 0, width)
  }
}

println("Square : " + new Square(80))

/*
8. "8.6 필드 오버라이드하기"에 나오는 Person과 SecretAgent 클래스를 컴파일하고 javap로
클래스 파일을 분석하라. name 필드가 몇개나 있는가? name 게터 메소드가 몇 개나 있는가?
게터 메소드들은 무엇을 얻는가? (힌트 -c와 -private 옵션을 사용한다.)
*/
println("# 8.8 ---")
println(
  """
    | Chap08Ex08.scala 참조.
    |
    | Person.class
    |$ javap -c -private Person
    |Compiled from "Chapter08Ex08.scala"
    |public class Person {
    |  private final java.lang.String name;
    |
    |  public java.lang.String name();
    |    Code:
    |       0: aload_0
    |       1: getfield      #13                 // Field name:Ljava/lang/String;
    |       4: areturn
    |
    |  public java.lang.String toString();
    |    Code:
    |       0: new           #18                 // class scala/collection/mutable/StringBuilder
    |       3: dup
    |       4: invokespecial #22                 // Method scala/collection/mutable/StringBuilder."<init>":()V
    |       7: aload_0
    |       8: invokevirtual #26                 // Method java/lang/Object.getClass:()Ljava/lang/Class;
    |      11: invokevirtual #31                 // Method java/lang/Class.getName:()Ljava/lang/String;
    |      14: invokevirtual #35                 // Method scala/collection/mutable/StringBuilder.append:(Ljava/lang/Object;)Lscala/collection/mutable/StringBuilder;
    |      17: ldc           #37                 // String [name=
    |      19: invokevirtual #35                 // Method scala/collection/mutable/StringBuilder.append:(Ljava/lang/Object;)Lscala/collection/mutable/StringBuilder;
    |      22: aload_0
    |      23: invokevirtual #39                 // Method name:()Ljava/lang/String;
    |      26: invokevirtual #35                 // Method scala/collection/mutable/StringBuilder.append:(Ljava/lang/Object;)Lscala/collection/mutable/StringBuilder;
    |      29: ldc           #41                 // String ]
    |      31: invokevirtual #35                 // Method scala/collection/mutable/StringBuilder.append:(Ljava/lang/Object;)Lscala/collection/mutable/StringBuilder;
    |      34: invokevirtual #43                 // Method scala/collection/mutable/StringBuilder.toString:()Ljava/lang/String;
    |      37: areturn
    |
    |  public Person(java.lang.String);
    |    Code:
    |       0: aload_0
    |       1: aload_1
    |       2: putfield      #13                 // Field name:Ljava/lang/String;
    |       5: aload_0
    |       6: invokespecial #45                 // Method java/lang/Object."<init>":()V
    |       9: return
    |}
    |
    |$ javap -c -private SecretAgent
    |Compiled from "Chapter08Ex08.scala"
    |public class SecretAgent extends Person {
    |  private final java.lang.String name;
    |
    |  private final java.lang.String toString;
    |
    |  public java.lang.String name();
    |    Code:
    |       0: aload_0
    |       1: getfield      #14                 // Field name:Ljava/lang/String;
    |       4: areturn
    |
    |  public java.lang.String toString();
    |    Code:
    |       0: aload_0
    |       1: getfield      #18                 // Field toString:Ljava/lang/String;
    |       4: areturn
    |
    |  public SecretAgent(java.lang.String);
    |    Code:
    |       0: aload_0
    |       1: aload_1
    |       2: invokespecial #22                 // Method Person."<init>":(Ljava/lang/String;)V
    |       5: aload_0
    |       6: ldc           #24                 // String secret
    |       8: putfield      #14                 // Field name:Ljava/lang/String;
    |      11: aload_0
    |      12: ldc           #24                 // String secret
    |      14: putfield      #18                 // Field toString:Ljava/lang/String;
    |      17: return
    |}
    |
    |Person과 SecretAgent는 각자 name 필드를 가지고 있고, 각자 name() 게터를 가지고 있다.
    |
  """.stripMargin)

/*
9. "8.10 생성 순서와 조기 정의"에 나오는 Creature 클래스에서 val range를 def로
바꾸라. Ant 클래스에서도 def를 사용하면 어떤 일이 발생하나? 서브클래스에서 val을
사용하면 어떤 일이 발생하나? 왜 그런가?
*/
println("#8.9 ---")

class Creature {
  def range: Int = 10
  val env: Array[Int] = new Array[Int](range)
}

class Ant extends Creature {
  override def range = 2
}

class AntVal extends Creature {
  override val range = 2
}

val ant = new Ant
println("Ant.env.size() : " + ant.env.size)
val antVal = new AntVal
println("AntVal.env.size() : " + antVal.env.size)

println(
  """
    |Creature 생성시 호출되는 range는 Ant 클래스에 오버라이드된 메소드이고,
    |이 메소드는 Ant 클래스의 초기화와 상관없이 메소드 내부 로직을 실행하므로
    |올바른 값인 2를 리턴한다.
    |그에반해 AntVal은 Creature 생성시 호출되는 range가 메소드내에서 즉시 값을 리턴하지
    |않고 아직 초기화 되지 않은 AntVal의 range 필드 값(0)을 리턴하게 된다.
  """.stripMargin)


/*
10. scala/collection/immutable/Stack.scala 파일은 다음 정의를 포함한다.
  class Stack[A] protected (protected val elems: List[A])
protected 키워드의 의미를 설명하라. (힌트: 5장의 비공개 생성자 논의를 되짚어본다.)
*/

println("#8.10 ---")
println(
  """
    |protected는 서브클래스에서만 접근 가능한 가시성이다.
    |따라서 기본 생성자가 protected라 함은 서브 클래스들만 해당 생성자를 호출할 수
    |있다는 뜻으로 보인다.
  """.stripMargin)