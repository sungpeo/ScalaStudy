/** Chapter 01 **/
/*
문제에 오역이 좀 있다. 아래에서 문제 자체를 검색해서 확인해 볼 것.
Java 7 이상에서 실행할 것.

https://www.google.co.kr/search?client=ubuntu&channel=fs&q=scala+for+the+impatient+exercise&ie=utf-8&oe=utf-8&gws_rd=cr&redir_esc=&ei=oqvrUb-1B6LwiQfjk4GQBg

Scala Doc : http://www.scala-lang.org/api/current/index.html
*/

/*
1. 스칼라 REPL에서 3을 입력하고 탭 키를 눌러라. 어떤 메소드를 부를 수 있나?
*/
println("# 1.1 --")
println(
  """
    |!=             ##             %              &              *              +              -              /              <              <<
    |<=             <init>         ==             >              >=             >>             >>>            ^              asInstanceOf   equals
    |getClass       hashCode       isInstanceOf   toByte         toChar         toDouble       toFloat        toInt          toLong         toShort
    |toString       unary_+        unary_-        unary_~        |
    |
  """.stripMargin)

/*
스칼라 REPL에서 3의 제곱근을 계산하고 그 값을 제곱하라. 결과가 3과 얼마나 차이가 나는가?
(힌트: res 변수를 활용하라.)
 */
println("# 1.2 --")
val squareRootOf3 = math.sqrt(3)
println("sqrt of 3 : " + squareRootOf3)
println("sqrt of 3 * sqrt of 3 : " + (squareRootOf3 * squareRootOf3))

/*
3. res 변수들은 val인가 var인가?
 */
println("# 1.3 --")
println(
  """
    |scala> res1 = 23423.32
    |<console>:8: error: reassignment to val
    |       res1 = 23423.32
    |            ^
    |
    |오류 메시지로 보건에 val 이다.
  """.stripMargin)

/*
4. 스칼라에서는 문자열을 숫자로 곱할 수 있다. "crazy" * 3을 REPL에서 해보라.
이 연산은 무엇을 하나? 스칼라독 어디에서 이를 찾을 수 있나?
 */
println("# 1.4 --")

println("\"crazy\" * 3 : " + ("crazy" * 3))
println(
  """
    |문자열에 대한 곱셈은 해당 문자열을 곱하기 값만큼 반복한 문자열을 생성해준다.
    |StringOpts에서 볼 수 있다.
    |http://www.scala-lang.org/api/current/index.html#scala.collection.immutable.StringOps
  """.stripMargin)

/*
5. 10 max 2는 무엇을 의미하나? max 메소드는 어느 클래스에 정의되어 있나?
 */
println("# 1.5 --")
println("10 max 2 : " + (10 max 2))
println(
  """
    | 둘 중에 큰값 리턴.
    |RitchInt 에 코드 들어 있음.
  """.stripMargin)

/*
6. BigInt를 사용하여 2^1024를 계산하라.
 */
println("# 1.6 --")
println("2^1024 " + BigInt(2).pow(1024))

/*
7. probablePrime과 Random에 아무런 식별자 없이 probablePrime(100, Random)으로
임의의 소수를 얻으려면 무엇을 임포트해야하나?
 */
println("# 1.7 --")
import scala.BigInt._
import scala.util.Random

println("임의의 소수 : " + probablePrime(10, Random))

/*
8. 임시의 파일 혹은 디렉토리 이름을 생성하는 방법 중 하나는 임의의 BigInt를
생성하고 이를 36진법으로 변환하여 "qsnvbevtomcj38o06kul" 같은 문자열을 얻는
것이다. 스카라독을 뒤져 Scala에서 이를 할 방법을 찾아라.
 */
println("# 1.8 --")
println("임의의 소수를 생성하여 32진법으로 표기 : " +  BigInt.probablePrime(128, Random).toString(32))

/*
스칼라에서 문자열의 첫 문자를 어떻게 얻는가? 마지막 문자는 어떻게 얻는가?
 */
println("# 1.9 --")
val str = "Hello, World!"
println("first letter : " + str(0) + ", last letter : " + str.last)

/*
10. 문자열 함수 take, drop, takeRight, dropRight는 무엇을 하나? substring을
사용하는 것에 비해 장점과 단점은 무엇인가?
 */
println("# 1.10 --")
println("Hello, World!".drop(6).dropRight(1))
println(
  """
    |drop/take 를 사용하는 것이 substring보다 훨씬 직관적이다.
  """.stripMargin)