/** Chapter 02 **/

/*
1. 숫자의 signum은 숫자가 양수이면 1, 음수이면 -1, 0이면 0이다. 이 값을 계산하는
함수를 작성하라.
 */
println("# 2.1 --")
def signum(num: Int) = {
  if (num > 0) 1 else if (num < 0) -1 else 0
}

println("양수 : " + signum(23))
println("음수 : " + signum(-128))
println("영 : " + signum(0))

/*
2. 빈 븍록시 {}의 값은 무엇인가? 타입은 무엇인가?
 */
println("# 2.2 --")
println("{} = " + {} + ", isInstanceof Unit = " + {}.isInstanceOf[Unit])
// # 2.2 {} = (), isInstanceof Unit = true

/*
3. 스칼라에서 x = y = 1 할당이 유효한 상황 하나만 말해보라. (힌트 적당한 x 타입을 고른다)
 */
println("# 2.3 --")
var x: Unit = ()
var y = 0
x = y = 1
println("x 가 Unit 타입일 때? - " + x)

/*
4. 자바 루프 for (int i = 10; i >= 0; i++) System.out.println(i); 와 동일한
스칼라 코드를 작성하라.
 */
println("# 2.4 --")
for (i <- 10 to(0,-1)) println(i)

/*
5. n부터 0까지 숫자를 출력하는 countdown(n: Int) 프로시저를 작성하라.
 */
println("# 2.5 --")

def countdown(n: Int) {
  val step = if (n < 0) 1 else -1
  printf("from %d to 0 -> ", n)
  for (i <- n to(0,step)) print(i + ", ")
  println("-- end")
}
countdown(-10)
countdown(0)
countdown(10)

/*
6. 문자열의 모든 문자의 유니코드를 곱하는 for 루프를 작성하라. 예를들어
"Hello"문자들의 곱은 9415087488L이다.
 */
println("# 2.6 --")

var product = 1L
for (c <- "Hello") {
  product *= c.toLong
}
println("Hello is " + product)

/*
7. 6번 문제를 루프를 쓰지 않고 풀어보라.(힌트 스칼라독의 StringOps를 살펴본다.)
 */
println("# 2.7 --")
/*
11페이지의 함수를 인자로 가지는 메소드를 기반으로 문제를 푼다.
 */
println("Hello의 모든 곱 with map,product : " + "Hello".map(_.toLong).product )

/*
8. 6번 문제에서 기술한 바와 같이 곱을 계산하는 product(s: String) 함수를 작성하라.
 */
println("# 2.8 --")
def product(s: String) = {
  var product = 1L
  for (c <- s) {
    product *= c.toLong
  }
  product
}
println("Hello with product() " + product("Hello"));

/*
9. 6번 문제의 함수를 재귀함수로 만들라.
 */
println("# 2.9 --")
def recursiveMultiply(chars: Char*): Long = {
  if (chars.length == 0) return 1L
  chars.head * recursiveMultiply(chars.tail: _*)
}

println("Hello with recursiveMultiply is " + recursiveMultiply("Hello".toCharArray: _*))

/*
10. n은 정수인 x^n을 계산하는 함수를 작성하라. 다음 재귀 정의를 이용하라.
- n이 양의짝수이고, y = x^(n/2)이면 x^n = y^2
- n이 양의 홀수이면 x^n = x*x^(n-1)
- x^0 = 1
- n이 음수이면 x^n = 1 / x^-n
return 문을 사용하지 않는다.
 */
println("# 2.10 --")

def mypow(x: Long, n: Long): Long = {
  if (n > 0) {
    if (n % 2 == 0 && n > 2) mypow(mypow(x, n/2), 2)
    else x * mypow(x, n-1)
  } else if (n < 0) 1 / mypow(x, -n)
  else 1L
}
def printpow(x: Long, n: Long) {
  printf("%d^%d = by mypow %d, by math.pow  = %d%n", x, n, mypow(x,n), math.pow(x, n).toLong)
}
printpow(2,3)
printpow(4, 10)
printpow(4, -10)
printpow(5, 1)
printpow(10,0)