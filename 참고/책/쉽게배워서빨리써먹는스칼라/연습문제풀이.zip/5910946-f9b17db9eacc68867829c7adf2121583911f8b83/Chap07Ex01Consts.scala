package com.horstmann

object Chap07Ex01Consts {
  val horstmannValue = "Horstmann's scala for the impatient."
}
