package random

package object random {
  private val a = 1664525
  private val b = 1013904223
  private val n = 32

  private var seed : Int = 0

  def next(): Double = {
    seed = seed * a + b % (2 * n)
    seed
  }

  def nextDouble(): Double = {
    next()
  }

  def nextInt(): Int = {
    next().toInt
  }

  def setSeed(seed: Int) {
    this.seed = seed
  }
}

object Test extends App {
  random.setSeed(123123)
  println("NextInt : " + random.nextInt())
  println("NextInt : " + random.nextInt())
  println("NextInt : " + random.nextInt())

  println("NextDouble : " + random.nextDouble())
  println("NextDouble : " + random.nextDouble())
  println("NextDouble : " + random.nextDouble())
}
