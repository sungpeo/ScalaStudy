/** Chapter 06 **/

/*
1. inchesToCentimeters, gallonsToLiters, milesToKilometers 메소드를 가지는 Conversions
오브젝트를 작성하라.
*/
println("# 6.1 ---")
object Conversions {

  // http://www.manuelsweb.com/in_cm.htm
  // in * 2.54 = cm
  def inchesToCentimeters(inches: Double) = {
    inches * 2.54
  }

  // http://www.nomoreodor.com/gallons_to_liters_conversion.htm
  // gallons * 3.7854 = liters
  def gallonsToLiters(gallons: Double) = {
    gallons * 3.7854
  }

  // http://www.metric-conversions.org/length/miles-to-kilometers.htm
  // mi * 1.6093 = km
  def milesToKilometers(miles: Double) = {
    miles * 1.6093
  }
}
println(1/0.62137)
println("12 inches = " + Conversions.inchesToCentimeters(12))
println("50 gallons = " + Conversions.gallonsToLiters(50))
println("80 miles = " + Conversions.milesToKilometers(80))

/*
2. 이전 문제는 그다지 객체 지향적이지 않다. 일반적인 슈퍼클래스인 UnitConversion을 제공하고
이를 확장하는 InchesToCentimeters, GallonsToLiters, MilesToKilometers 오브젝트를 정의하라.
*/
println("# 6.2 ---")

abstract class UnitConversion(val multipliedBy: Double) {
  def convert(value: Double) = {
    value * multipliedBy
  }
}

object InchesToCentimeters extends UnitConversion(2.54) {
}

object GallonsToLiters extends UnitConversion(3.7854) {
}

object MilesToKilometers extends UnitConversion(1.6093) {
}

println("12 inches = " + InchesToCentimeters.convert(12))
println("50 gallosn = " + GallonsToLiters.convert(50))
println("80 miles = " + MilesToKilometers.convert(80))

/*
3. java.awt.Point를 확장하는 Origin 오브젝트를 정의하라. 이는 왜 좋은 생각이 아닌가?
(Point 클래스의 메소드를 자세히 살펴본다.)
*/

println("# 6.3 ---")

object Origin extends java.awt.Point {

}

// public x, y 때문에? 그리고 mutable 한 메소드때문에?
// Origin이라는 이름은 근본, 근원이라는 뜻을 담고 있고 이는 값이 바뀌어서는 안된다는 의미.
// mutable methods 때문에 값을 바꿀 수 있음.

/*
4. Point 클래스를 컴패니언 오브젝트와 함께 정의하여 new 없이 Point(3,4)와 같은
Point 인스턴스를 생성할 수 있게 하라.
*/

println("# 6.4 ---")

class Point private (val x: Int, val y: Int) {

  override def toString() = "Point { x = " + x + ", y = " + y + " }"
}

object Point {
  def apply(x: Int, y: Int) = {
    new Point(x, y)
  }
}

println(Point(10, 20))

/*
5. App 트레이트를 이용하여 명령 줄 인자를 공백으로 구분하여 역순으로 출력하는 스칼라 애플리케이션을
작성하라. 예를들어 scala Revers Hello World는 World hello를 출력해야 한다.
*/
println("# 6.5 ---")

object Reverse extends App {
  for(arg <- args.reverse) {
    print(arg + " ")
  }

  println()
}

/*
6. 4개의 카드 세트를 묘사하는 이뉴머레이션을 작성하여 toString 메소드가 ♣, ◆, ♥, ♠를 리턴하게 만들어라3
https://en.wikipedia.org/wiki/Playing_card
*/
println("# 6.6 ---")

object Card extends Enumeration {
  type Card = Value
  val Spade = Value(0, "♠")
  val Heart = Value(1, "♥")
  val Diamond = Value(2, "◆")
  val Club = Value(3, "♣")
}

import Card._
println(Spade)
println(Heart)
println(Diamond)
println(Club)

/*
7. 이전 문제 카드 세트 값이 빨강인지 확인하는 함수를 구현하라.
*/

println("# 6.7 ---")

def isRed(card: Card) = {
  card == Heart || card == Diamond
}

println("Spade is red? " + isRed(Spade))
println("Heart is red? " + isRed(Heart))
println("Diamond is red? " + isRed(Diamond))
println("Club is red? " + isRed(Club))

/*
8. RGC 색상 큐브의 8개의 모서리를 나타내는 이뉴머레이션을 작성하라. ID로 색상 값을 사용하라.
(예: 0xff0000은 빨강)
*/

println("# 6.8 ---")

// http://prosjekt.ffi.no/unik-4660/lectures04/chapters/jpgfiles/RGB_cube_color.jpg 참조
// 위 이미지에서 1은 사실 ff 를 뜻함.
object RGBCube extends Enumeration {
  type RGBCube = Value
  val Blue = Value(0x0000ff)
  val Cyan = Value(0x00ffff)
  val White = Value(0xffffff)
  val Green = Value(0x00ff00)
  val Yellow = Value(0xffff00)
  val Red = Value(0xff0000)
  val Black = Value(0x000000)
  val Magenta = Value(0xff00ff)
}

// http://alvinalexander.com/scala/scala-string-formatting-java-string-format-method 참조
for (color <- RGBCube.values) {
  println(color + " -> " + "0x%06X".format(color.id))
}