object Hello extends App {
  println("Hello, World!")
}
