// Type these commands into the REPL, or run scala script.scala 

print("Answer: ")
println(42)

println("Answer: " + 42)

printf("Hello, %s! You are %d years old.\n", "Fred", 42)

val name = readLine("Your name: ")

print("Your age: ")
val age = readInt()

printf("Hello, %s! Next year, you will be %d.\n", name, age + 1)
