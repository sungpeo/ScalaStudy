// These are meant to be typed into the REPL. You can also run
// scala -Xnojline < repl-session.scala to run them all at once.

val x = 0

if (x > 0) 1 else -1

val s = if (x > 0) 1 else -1

if (x > 0) "positive" else -1

if (x > 0) 1


