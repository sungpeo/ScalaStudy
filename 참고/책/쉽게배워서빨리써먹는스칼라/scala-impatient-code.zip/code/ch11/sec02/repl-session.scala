// These are meant to be typed into the REPL. You can also run
// scala -Xnojline < repl-session.scala to run them all at once.

1 to 10
1.to(10)

1 -> 10
1 .->(10) 
1.->10 // Here 1. is a floating-point number

