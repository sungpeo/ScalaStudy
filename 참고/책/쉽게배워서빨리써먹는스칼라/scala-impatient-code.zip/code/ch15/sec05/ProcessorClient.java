public class ProcessorClient { // This is Java
   public static void main(String[] args) {
      new Processor().process("Mary", "had", "a", "little", "lamb");
   }
}

