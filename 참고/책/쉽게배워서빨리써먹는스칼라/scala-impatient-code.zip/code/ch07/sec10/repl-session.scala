// These are meant to be typed into the REPL. You can also run
// scala -Xnojline < repl-session.scala to run them all at once.

new String("Fred") // from the java.lang package
new StringBuilder // from the scala package, not java.lang
new java.lang.StringBuilder

println("Hello") // from the Predef object

new collection.mutable.HashMap[String, Int]
new scala.collection.mutable.HashMap[String, Int]


  
