package com.horstmann.impatient

class Car
