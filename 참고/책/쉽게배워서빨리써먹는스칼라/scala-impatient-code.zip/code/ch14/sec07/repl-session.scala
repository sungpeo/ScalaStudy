// These are meant to be typed into the REPL. You can also run
// scala -Xnojline < repl-session.scala to run them all at once.

val (x, y) = (1, 2)

val (q, r) = BigInt(10) /% 3

val arr = Array(1, 7, 2, 9)

val Array(first, second, _*) = arr

