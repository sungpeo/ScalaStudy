java -cp .:/home/sites/projects/scalabook/lib/scala-compiler-2.7.1-svn15611.jar:/home/sites/projects/scalabook/lib/scala-library-2.7.1-svn15611.jar:/Users/bv/nobkp/delus/swing/lib/scala-swing.jar scala.tools.nsc.Main *.scala

